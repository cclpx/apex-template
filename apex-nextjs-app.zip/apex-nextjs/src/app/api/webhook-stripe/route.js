import Stripe from 'stripe'
import { createClient } from '@supabase/supabase-js'
import { headers } from 'next/headers'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

export async function POST(req) {
  const body = await req.text()
  const sig  = headers().get('stripe-signature')

  let event
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    return new Response(`Webhook error: ${err.message}`, { status: 400 })
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object
    const { prospecto_id, slug, plan, negocio } = session.metadata

    // 1. Marcar pago como confirmado en Supabase
    await supabase
      .from('pagos')
      .update({ estado: 'confirmado', fecha_pago: new Date().toISOString() })
      .eq('stripe_session_id', session.id)

    // 2. Actualizar estado del prospecto
    await supabase
      .from('prospectos')
      .update({
        estado: 'pagado',
        plan_comprado: plan,
        fecha_pago: new Date().toISOString(),
        stripe_customer_id: session.customer,
      })
      .eq('id', prospecto_id)

    // 3. Notificar a N8N para que inicie el deploy
    await fetch(process.env.N8N_WEBHOOK_PAGO, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        evento: 'pago_confirmado',
        prospecto_id, slug, plan, negocio,
        email_cliente: session.customer_email,
        monto: session.amount_total / 100,
      })
    }).catch(() => {})
  }

  return new Response('ok', { status: 200 })
}
