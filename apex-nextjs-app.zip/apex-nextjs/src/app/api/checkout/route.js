import Stripe from 'stripe'
import { createClient } from '@supabase/supabase-js'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

export async function POST(req) {
  const { prospecto_id, slug, plan, precio, negocio, email } = await req.json()

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{
      price_data: {
        currency: 'usd',
        product_data: {
          name: `Sitio web profesional — ${negocio}`,
          description: `Plan ${plan} · Apex Digital Growth`,
        },
        unit_amount: precio * 100,
      },
      quantity: 1,
    }],
    mode: 'payment',
    success_url: `${process.env.NEXT_PUBLIC_URL}/propuesta/${slug}/gracias?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url:  `${process.env.NEXT_PUBLIC_URL}/propuesta/${slug}`,
    customer_email: email || undefined,
    metadata: { prospecto_id, slug, plan, negocio },
  })

  // Registrar intento de pago en Supabase
  await supabase
    .from('pagos')
    .insert({
      prospecto_id,
      stripe_session_id: session.id,
      plan, monto_usd: precio,
      estado: 'pendiente',
      fecha: new Date().toISOString(),
    })

  return Response.json({ sessionId: session.id })
}
