import { createClient } from '@supabase/supabase-js'
import { notFound } from 'next/navigation'
import ProposalPage from '@/components/ProposalPage'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

export async function generateMetadata({ params }) {
  const { data } = await supabase
    .from('prospectos')
    .select('nombre, ciudad, sector')
    .eq('slug', params.slug)
    .single()
  if (!data) return { title: 'Apex Digital Growth' }
  return {
    title: `Tu sitio web — ${data.nombre} | Apex Digital Growth`,
    description: `Hemos creado un sitio web profesional para ${data.nombre} en ${data.ciudad}. Vélo ahora.`,
    openGraph: {
      title: `${data.nombre} — Tu nuevo sitio web está listo`,
      description: `Apex Digital Growth creó un sitio profesional para tu negocio. Ábrelo aquí.`,
    }
  }
}

export default async function Page({ params }) {
  const { data: prospecto, error } = await supabase
    .from('prospectos')
    .select('*')
    .eq('slug', params.slug)
    .single()

  if (error || !prospecto) notFound()

  // Registrar visita
  await supabase
    .from('visitas')
    .insert({ prospecto_id: prospecto.id, fecha: new Date().toISOString() })

  return <ProposalPage prospecto={prospecto} />
}
