export default function Gracias() {
  return (
    <div style={{
      minHeight:'100vh', display:'flex', flexDirection:'column',
      alignItems:'center', justifyContent:'center', textAlign:'center',
      padding:'2rem', fontFamily:'Inter,sans-serif', background:'#f8fafc',
    }}>
      <div style={{
        width:80, height:80, borderRadius:'50%',
        background:'#dcfce7', display:'flex', alignItems:'center',
        justifyContent:'center', fontSize:'2.5rem', marginBottom:'2rem',
      }}>✓</div>
      <h1 style={{ fontSize:'2rem', fontWeight:700, marginBottom:'1rem' }}>
        ¡Pago confirmado!
      </h1>
      <p style={{ color:'#64748b', maxWidth:440, lineHeight:1.7, marginBottom:'2rem' }}>
        Tu sitio web está siendo configurado. En las próximas <strong>2-4 horas</strong> recibirás un email con tu URL definitiva y las instrucciones de acceso.
      </p>
      <p style={{ color:'#94a3b8', fontSize:'0.85rem' }}>
        ¿Dudas? Escríbenos al WhatsApp de Apex Digital Growth
      </p>
    </div>
  )
}
